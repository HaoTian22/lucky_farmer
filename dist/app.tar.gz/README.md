# Introduction
This is a simple calculator of our group project board game **lucky farmer**.

It's a strategy game about growing and harvesting.

When we create this board game, we find the calculation in the game boring and complex.   

Ridiculously, it requires players to do a series of value calculations every minute, which drive players to focus on calculation instead of the strategy in the game.
So we decided to make a computer calculator to increase players' pleasure.

# Play
Download [calulator](/lucky_farmer.py), run it in Python.  

See the end of [rules](/rules.md) to prepare nesseary cards.  

Follow the rules to play.  

Have fun 😊.
